# Trashcat's Variety Mod
This is basically just a mod for me and my friends.
## Content
### Food
- Stove
- Quaso
- Hamburber
### Portal 2
- Potato GLADOS (W.I.P.)
- Wheatley (Coming Soon)
- Space Core (Coming Soon)
- Fact Core (Coming Soon)
- Adventure Core (Coming Soon)
### Minecraft
- Diamond Sword (W.I.P.)
### Random
- U i i a i Cat
- Mr. Whale (Includes Wacky Voice lines made by Karma (We are not liable for loss of hearing))
- Car (Coming Soon)
- Keyboard (Coming Soon)
- Mouse (Coming Soon)
## Credits
### Voice Acting
Karmawillgetchew ma friend
### Models from Sketchfab (Some unused as of now)
"CC0 - Croissant" (https://skfb.ly/prNn8) by plaggy is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
"CC0 - Hamburger" (https://skfb.ly/prsWX) by plaggy is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
"Whale" (https://skfb.ly/oqZvL) by Mofn is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
"Russian_Stove_GameReady_LowPoly_Asset_Props" (https://skfb.ly/psutx) by RahulTambat is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
"Oiiaioooooiai Cat" (https://skfb.ly/prRXD) by Zhuier is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
"orange car" (https://skfb.ly/oF6KD) by sikoro is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
"Wheatley core - from portal 2 (original)" (https://skfb.ly/oAMyy) by D3DARTM is licensed under Creative Commons Attribution-NonCommercial (http://creativecommons.org/licenses/by-nc/4.0/).
"Space core - from portal 2 (original)" (https://skfb.ly/oAQIA) by D3DARTM is licensed under Creative Commons Attribution-NonCommercial (http://creativecommons.org/licenses/by-nc/4.0/).
"Fact Core - from portal 2 (original)" (https://skfb.ly/oAKFp) by D3DARTM is licensed under Creative Commons Attribution-NonCommercial (http://creativecommons.org/licenses/by-nc/4.0/).
"Adventure Core - from portal 2 (original)" (https://skfb.ly/oAMyB) by D3DARTM is licensed under Creative Commons Attribution-NonCommercial (http://creativecommons.org/licenses/by-nc/4.0/).
"Potato GLADOS - From Portal 2" (https://skfb.ly/oAzq6) by D3DARTM is licensed under Creative Commons Attribution-NonCommercial (http://creativecommons.org/licenses/by-nc/4.0/).
"Razer Cynosa v2 RGB Gaming Keyboard" (https://skfb.ly/oQDyS) by creamycreamcreme is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
"Ice Claw mouse" (https://skfb.ly/6VAnx) by dmitriy7776661111 is licensed under Creative Commons Attribution (http://creativecommons.org/licenses/by/4.0/).
